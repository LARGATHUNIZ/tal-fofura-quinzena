function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
} //variáveis da bolinha 
// let xbolinha = 300;
let ybolinha = 200;
let diametro = 13;
let raio = diamentro / 2 ;

//velocidadde da bolinha 
let velocidadexbolinha = 6 ;
let velocidadeybolinha = 6 ;
let raquetecomprimento = 10 ;
let raquealtura = 90 ;

//variáveis da raquete
let xraquete = 5 ;
let yraquete = 150 ;

//variáveis do oponente
let xraqueteoponente = 585 ;
let yraqueteooponente = 150 ;
let velocidadeyooponente ;
let colidiu = false ;

//placar do jogo
let meusponto = 0 ;
let pontosdooponente = 0;
 
//sons do jogo
let ponto;
let raquetada;
let trilha;

function preloand(){
  trilha = loadsound(||trilha.mp3'');
  raquetada = loadsound(||raquetada.mp3);
  ponto = loadsound (||ponto.mp3);
}

function setup () {
  createcanvas(600,400);
  trilha.loop();
}

function draw() {
  background(0);
  mostrabolinha();
  movimentabolinha();
  verificacolisaoborda();
  mostraraquete(xraquete, yraquete);
  movimentaminharaquete();
  //verificacolisaoraquete();
  verificacolisaoraquete(xraquete, yraquete);
  mostraraquete(xraqueteoponete, yraqueteoponente);
  movimentaraqueteoponente();
  verificacolisaoraquete(xraqueteoponente, yraqueteoponente);
  incluiplacar();
  marcaponto();
}

function mostrabolinha(){
  circle(xbolinha, ybolinha, diamentro);
}

function movimentabolinha(){
  xbolinha += velocidadexbolinha;
  ybolinha+= velocidadeybolinha;
}

functio verificacolisaoborda(){
  if (xbolinha + raio> width ||
     xbolinha - raio< 0){
    velocidadeybolinha *=-1;
  }
  if (ybolinha + raio> height ||
     ybolinha - raio < 0){
  velocidadeybolinha * =  -1;
function mostraRaquete (x , y) {
  rect(x, y , raqueteComprimento,
      raqueteAltura) ;
function movimentaMinhaRaquete( ) {
  if (keyIsDown(UP_ARROW)) {
    YRaquete+= 10;
    function verificaColisaoRaquete() {
      if (xbolinha -  raio < xRaquete + raquetecomprimento && ybolinha)